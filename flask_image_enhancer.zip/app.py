from flask import Flask, render_template, request, redirect, url_for
import os
import numpy as np
import cv2
from PIL import Image
from tensorflow.keras.models import load_model
from keras.preprocessing.image import img_to_array, save_img, array_to_img

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['OUTPUT_FOLDER'] = 'static/output/'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)

# Load the model
MODEL_PATH = "generator.h5"  # Ensure model is in the root folder
model = load_model(MODEL_PATH)

def process_image(image_path):
    """Enhances the image using the loaded model."""
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    original_shape = img.shape[:2]
    
    img_arr = (img_to_array(img) - 127.5) / 127.5
    resized = cv2.resize(img_arr, (256, 256), interpolation=cv2.INTER_AREA)
    ready_img = np.expand_dims(resized, axis=0)
    
    pred = model.predict(ready_img)
    pred = (pred[0] + 1) / 2
    pred = (pred * 255).astype(np.uint8)
    
    pred_resized = cv2.resize(pred, (original_shape[1], original_shape[0]), interpolation=cv2.INTER_CUBIC)
    pred_resized = array_to_img(pred_resized)
    
    output_path = os.path.join(app.config['OUTPUT_FOLDER'], 'output.png')
    save_img(output_path, pred_resized)
    return output_path

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        
        output_path = process_image(file_path)
        return render_template('index.html', original=file_path, enhanced=output_path)
    
    return render_template('index.html', original=None, enhanced=None)

if __name__ == '__main__':
    app.run(debug=True)